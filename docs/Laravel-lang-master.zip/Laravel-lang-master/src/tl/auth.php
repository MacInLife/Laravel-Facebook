<?php

return [
    /*
    |--------------------------------------------------------------------------
    | Authentication Language Lines
    |--------------------------------------------------------------------------
    |
    | The following language lines are used during authentication for various
    | messages that we need to display to the user. You are free to modify
    | these language lines according to your application's requirements.
    |
    */

    'failed'   => 'Ang credentials na ito ay hindi katugma ng nasa rekord namin.',
    'throttle' => 'Sobrang daming pagtatangkang mag-login. Pakisubukan ulit sa :segundo segundo.',
];
